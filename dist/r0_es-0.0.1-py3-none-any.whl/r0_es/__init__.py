from es_tools import *
from cfg_settings import set_es_config, get_es_config


def hello_world():
    """
    **Welcome to use r0's tools.**

    **Hope you have a happy day.**
    """
    pass
